import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getPublicImageUrl } from "@/lib/supabase/storage";
import {
  getFeaturedProjects,
  getPublicSkills,
  getPublicExperiences,
} from "@/lib/supabase/queries/public";
import { Container } from "@/components/public/Container";
import { FadeIn } from "@/components/public/FadeIn";
import { EmptyState } from "@/components/public/EmptyState";
import { ProjectCard } from "@/components/public/ProjectCard";
import { ProjectCarousel } from "@/components/public/ProjectCarousel";
import { Button } from "@/components/ui/button";

// ISR: halaman publik cache, revalidate via revalidatePath saat owner
// update konten (Architecture.md §2.1).
export const revalidate = 3600;

export default async function HomePage() {
  const supabase = await createClient();
  const [featuredProjects, skills, experiences] = await Promise.all([
    getFeaturedProjects(supabase),
    getPublicSkills(supabase),
    getPublicExperiences(supabase),
  ]);

  const featuredWithUrls = featuredProjects.map((p) => ({
    slug: p.slug,
    title: p.title,
    thumbnail_url: getPublicImageUrl(supabase, p.thumbnail),
    category: p.category,
    tahun: p.tahun,
    status: p.status,
    skillNames: (p.project_skill ?? []).map(
      (ps: { skills: { name: string } }) => ps.skills.name,
    ),
  }));

  const skillsByCategory = skills.reduce<Record<string, typeof skills>>(
    (acc, skill) => {
      (acc[skill.category] ??= []).push(skill);
      return acc;
    },
    {},
  );

  const recentExperiences = experiences.slice(0, 2);

  return (
    <>
      {/* ---------- Hero ---------- */}
      <section className="border-b border-line py-20 md:py-28">
        <Container>
          <FadeIn>
            <p className="font-mono text-xs text-ink-soft">hi, i&rsquo;m</p>
            <h1 className="mt-2 font-display text-[2rem] font-medium tracking-tight text-ink md:text-5xl">
              Your Name
            </h1>
            <p className="mt-4 max-w-xl text-ink-soft">
              Developer & designer yang suka membangun produk digital dari
              nol — dari riset masalah sampai ke detail interaksi.
            </p>
            <div className="mt-8 flex gap-3">
              <Link href="/projects">
                <Button className="rounded-full">Lihat Projects</Button>
              </Link>
              <a href="/cv.pdf" target="_blank" rel="noreferrer">
                <Button variant="outline" className="rounded-full">
                  Download CV
                </Button>
              </a>
            </div>
          </FadeIn>
        </Container>
      </section>

      {/* ---------- Featured Projects ---------- */}
      <section className="border-b border-line py-16">
        <Container>
          <FadeIn>
            <p className="inline-block rounded-md bg-[var(--butter-cream)] px-2 py-1 font-mono text-xs text-ink">
              projects
            </p>
            <h2 className="mt-3 font-display text-2xl font-medium text-ink">
              Featured Projects
            </h2>
          </FadeIn>

          <div className="mt-8">
            {featuredWithUrls.length === 0 && (
              <EmptyState message="Belum ada featured project." />
            )}
            {featuredWithUrls.length >= 3 ? (
              <ProjectCarousel projects={featuredWithUrls} />
            ) : (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                {featuredWithUrls.map((p) => (
                  <FadeIn key={p.slug}>
                    <ProjectCard project={p} />
                  </FadeIn>
                ))}
              </div>
            )}
          </div>
        </Container>
      </section>

      {/* ---------- Skills summary ---------- */}
      <section className="border-b border-line py-16">
        <Container>
          <FadeIn>
            <p className="inline-block rounded-md bg-[var(--butter-cream)] px-2 py-1 font-mono text-xs text-ink">
              skills
            </p>
            <h2 className="mt-3 font-display text-2xl font-medium text-ink">
              What I work with
            </h2>
          </FadeIn>

          <div className="mt-8 space-y-5">
            {Object.keys(skillsByCategory).length === 0 && (
              <EmptyState message="Belum ada skill ditambahkan." />
            )}
            {Object.entries(skillsByCategory).map(([category, items]) => (
              <FadeIn key={category}>
                <p className="font-mono text-xs text-ink-soft">{category}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {items.map((skill) => (
                    <span
                      key={skill.id}
                      className="rounded-full border border-line px-3 py-1 text-sm text-ink"
                    >
                      {skill.name}
                    </span>
                  ))}
                </div>
              </FadeIn>
            ))}
          </div>
        </Container>
      </section>

      {/* ---------- Recent experience ---------- */}
      <section className="py-16">
        <Container>
          <FadeIn>
            <p className="inline-block rounded-md bg-[var(--butter-cream)] px-2 py-1 font-mono text-xs text-ink">
              experience
            </p>
            <h2 className="mt-3 font-display text-2xl font-medium text-ink">
              Recent Experience
            </h2>
          </FadeIn>

          <div className="mt-8 space-y-4">
            {recentExperiences.length === 0 && (
              <EmptyState message="Belum ada experience ditambahkan." />
            )}
            {recentExperiences.map((exp) => (
              <FadeIn key={exp.id}>
                <div className="rounded-xl border border-line bg-white p-5">
                  <p className="font-mono text-xs text-ink-soft">
                    {exp.period_text}
                  </p>
                  <p className="mt-1 font-display text-lg font-medium text-ink">
                    {exp.role_title}
                  </p>
                  <p className="mt-2 text-sm text-ink-soft">
                    {exp.description}
                  </p>
                </div>
              </FadeIn>
            ))}
          </div>

          <div className="mt-6">
            <Link
              href="/experience"
              className="font-mono text-xs text-[var(--cobalt)] hover:underline"
            >
              Lihat semua experience →
            </Link>
          </div>
        </Container>
      </section>
    </>
  );
}
