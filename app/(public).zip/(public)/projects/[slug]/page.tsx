import { notFound } from "next/navigation";
import Image from "next/image";
import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { createStaticClient } from "@/lib/supabase/static";
import { getPublicImageUrl } from "@/lib/supabase/storage";
import {
  getProjectBySlug,
  getAllProjectSlugs,
} from "@/lib/supabase/queries/public";
import { Container } from "@/components/public/Container";
import { FadeIn } from "@/components/public/FadeIn";
import { StatusBadge } from "@/components/public/StatusBadge";
import { GalleryDialog } from "@/components/public/GalleryDialog";
import { GithubIcon } from "@/components/public/icons";

export const revalidate = 3600;

export async function generateStaticParams() {
  // Pakai static client, BUKAN createClient() dari lib/supabase/server.ts —
  // generateStaticParams jalan saat build time tanpa HTTP request, jadi
  // tidak boleh memanggil cookies() (yang dipakai server client untuk baca
  // session). Data yang diambil di sini toh cuma slug publik, tidak butuh
  // session sama sekali.
  const supabase = createStaticClient();
  const slugs = await getAllProjectSlugs(supabase);
  return slugs.map((s) => ({ slug: s.slug }));
}

// PRD.md §4.1: title, description, OG image dinamis per project supaya
// preview bagus saat di-share ke recruiter.
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const supabase = createStaticClient();

  let project;
  try {
    project = await getProjectBySlug(supabase, slug);
  } catch {
    return {};
  }
  if (!project) return {};

  return {
    title: project.title,
    description: project.description,
    openGraph: {
      title: project.title,
      description: project.description,
      images: [`/api/og?slug=${project.slug}`],
    },
  };
}

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const supabase = await createClient();

  let project;
  try {
    project = await getProjectBySlug(supabase, slug);
  } catch {
    notFound();
  }
  if (!project) notFound();

  const images = (project.project_images ?? [])
    .sort((a: { order: number }, b: { order: number }) => a.order - b.order)
    .map((img: { id: number; image_path: string; caption: string | null }) => ({
      id: img.id,
      url: getPublicImageUrl(supabase, img.image_path),
      caption: img.caption,
    }));

  const metrics = (project.project_metrics ?? []).sort(
    (a: { order: number }, b: { order: number }) => a.order - b.order,
  );

  const skills = (project.project_skill ?? []).map(
    (ps: { skills: { id: number; name: string } }) => ps.skills,
  );

  // Fallback ke `detail` kalau problem/approach/outcome semua kosong.
  const hasCaseStudy = project.problem || project.approach || project.outcome;

  return (
    <>
      <section className="border-b border-line py-16">
        <Container>
          <FadeIn>
            <div className="flex items-center gap-3">
              <p className="font-mono text-xs text-ink-soft">
                {project.category} · {project.tahun}
              </p>
              <StatusBadge status={project.status} />
            </div>
            <h1 className="mt-3 font-display text-3xl font-medium text-ink md:text-4xl">
              {project.title}
            </h1>
            <p className="mt-3 max-w-2xl text-ink-soft">
              {project.description}
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-4">
              {project.role && (
                <span className="font-mono text-xs text-ink-soft">
                  Role: {project.role}
                </span>
              )}
              {project.timeline && (
                <span className="font-mono text-xs text-ink-soft">
                  Timeline: {project.timeline}
                </span>
              )}
              {project.client && (
                <span className="font-mono text-xs text-ink-soft">
                  Client: {project.client}
                </span>
              )}
            </div>

            <div className="mt-6 flex gap-3">
              {project.demo_url && (
                <a
                  href={project.demo_url}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full bg-[var(--ink)] px-4 py-2 font-mono text-xs text-cream hover:bg-[var(--cobalt)]"
                >
                  Live Demo →
                </a>
              )}
              {project.github_url && (
                <a
                  href={project.github_url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 rounded-full border border-line px-4 py-2 font-mono text-xs text-ink hover:border-[var(--ink)]"
                >
                  <GithubIcon className="h-3.5 w-3.5" />
                  Source Code
                </a>
              )}
            </div>
          </FadeIn>

          <FadeIn delay={0.1}>
            <div className="relative mt-10 aspect-[16/9] w-full overflow-hidden rounded-xl border border-line">
              <Image
                src={getPublicImageUrl(supabase, project.thumbnail)}
                alt={project.title}
                fill
                priority
                sizes="(min-width: 1024px) 960px, 100vw"
                className="object-cover"
              />
            </div>
          </FadeIn>
        </Container>
      </section>

      {metrics.length > 0 && (
        <section className="border-b border-line py-12">
          <Container>
            <FadeIn>
              <div className="grid grid-cols-2 gap-6 sm:grid-cols-4">
                {metrics.map((m: { id: number; label: string; value: string }) => (
                  <div key={m.id}>
                    <p className="font-display text-2xl font-medium text-[var(--cobalt)]">
                      {m.value}
                    </p>
                    <p className="mt-1 text-xs text-ink-soft">{m.label}</p>
                  </div>
                ))}
              </div>
            </FadeIn>
          </Container>
        </section>
      )}

      {(hasCaseStudy || project.detail) && (
        <section className="border-b border-line py-16">
          <Container>
            {hasCaseStudy ? (
              <div className="space-y-10">
                {project.problem && (
                  <FadeIn>
                    <p className="font-mono text-xs text-ink-soft">problem</p>
                    <p className="mt-2 whitespace-pre-line text-ink">
                      {project.problem}
                    </p>
                  </FadeIn>
                )}
                {project.approach && (
                  <FadeIn>
                    <p className="font-mono text-xs text-ink-soft">approach</p>
                    <p className="mt-2 whitespace-pre-line text-ink">
                      {project.approach}
                    </p>
                  </FadeIn>
                )}
                {project.outcome && (
                  <FadeIn>
                    <p className="font-mono text-xs text-ink-soft">outcome</p>
                    <p className="mt-2 whitespace-pre-line text-ink">
                      {project.outcome}
                    </p>
                  </FadeIn>
                )}
              </div>
            ) : (
              <FadeIn>
                <p className="whitespace-pre-line text-ink">{project.detail}</p>
              </FadeIn>
            )}
          </Container>
        </section>
      )}

      {images.length > 0 && (
        <section className="border-b border-line py-16">
          <Container>
            <FadeIn>
              <p className="font-mono text-xs text-ink-soft">gallery</p>
              <div className="mt-4">
                <GalleryDialog images={images} />
              </div>
            </FadeIn>
          </Container>
        </section>
      )}

      {skills.length > 0 && (
        <section className="py-16">
          <Container>
            <FadeIn>
              <p className="font-mono text-xs text-ink-soft">skills used</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {skills.map((s: { id: number; name: string }) => (
                  <span
                    key={s.id}
                    className="rounded-full border border-line px-3 py-1 text-sm text-ink"
                  >
                    {s.name}
                  </span>
                ))}
              </div>
            </FadeIn>
          </Container>
        </section>
      )}
    </>
  );
}